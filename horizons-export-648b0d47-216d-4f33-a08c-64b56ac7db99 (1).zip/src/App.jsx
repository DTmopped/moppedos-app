import React from 'react';
import DragDropScheduler from '@/components/labor/DragDropScheduler';
import EmployeeManager from '@/components/labor/EmployeeManager';
import SchedulingDashboard from '@/components/labor/SchedulingDashboard'; 
import ConnectionTest from '@/components/ConnectionTest';
import ScheduleCrudTest from '@/components/ScheduleCrudTest';
import SimpleSupabaseTest from '@/components/SimpleSupabaseTest';
import CorsProxyTest from '@/components/CorsProxyTest';
import CustomProxyTest from '@/components/CustomProxyTest'; // Import the new component
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Toaster } from '@/components/ui/toaster';
import AppProviders from '@/AppProviders'; 
import { cn } from '@/lib/utils';

const AppContent = () => {
  return (
    <div className="container mx-auto py-8 px-4 bg-gradient-to-br from-slate-900 via-slate-800 to-gray-900 min-h-screen text-slate-100">
      <h1 className="text-4xl md:text-5xl font-extrabold mb-10 text-center">
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 via-pink-500 to-orange-400">
          Mopped OS
        </span>
        <span className="block text-xl md:text-2xl text-slate-400 font-medium mt-1 tracking-tight">
          Enhanced Scheduler & Dashboard
        </span>
      </h1>
      
      <Tabs defaultValue="dashboard" className="w-full max-w-7xl mx-auto"> {/* Increased max-width for more tabs */}
        <TabsList className="grid w-full grid-cols-3 sm:grid-cols-4 md:grid-cols-8 bg-slate-700/60 border border-slate-600/80 text-slate-300 rounded-lg p-1 shadow-md backdrop-blur-sm">
          <TabsTrigger 
            value="dashboard" 
            className={cn(
              "py-2.5 px-2.5 text-xs sm:text-sm rounded-md transition-all duration-200 ease-in-out", // Adjusted padding and text size
              "data-[state=active]:bg-gradient-to-r data-[state=active]:from-teal-500 data-[state=active]:to-cyan-500 data-[state=active]:text-white data-[state=active]:shadow-lg",
              "data-[state=inactive]:hover:bg-slate-600/70 data-[state=inactive]:text-slate-300"
            )}
          >
            Dashboard
          </TabsTrigger>
          <TabsTrigger 
            value="scheduler" 
            className={cn(
              "py-2.5 px-2.5 text-xs sm:text-sm rounded-md transition-all duration-200 ease-in-out",
              "data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white data-[state=active]:shadow-lg",
              "data-[state=inactive]:hover:bg-slate-600/70 data-[state=inactive]:text-slate-300"
            )}
          >
            Scheduler
          </TabsTrigger>
          <TabsTrigger 
            value="employees"
            className={cn(
              "py-2.5 px-2.5 text-xs sm:text-sm rounded-md transition-all duration-200 ease-in-out",
              "data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-rose-500 data-[state=active]:text-white data-[state=active]:shadow-lg",
              "data-[state=inactive]:hover:bg-slate-600/70 data-[state=inactive]:text-slate-300"
            )}
          >
            Employees
          </TabsTrigger>
          <TabsTrigger 
            value="connection"
            className={cn(
              "py-2.5 px-2.5 text-xs sm:text-sm rounded-md transition-all duration-200 ease-in-out",
              "data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-sky-500 data-[state=active]:text-white data-[state=active]:shadow-lg",
              "data-[state=inactive]:hover:bg-slate-600/70 data-[state=inactive]:text-slate-300"
            )}
          >
            Connection
          </TabsTrigger>
          <TabsTrigger 
            value="crud"
            className={cn(
              "py-2.5 px-2.5 text-xs sm:text-sm rounded-md transition-all duration-200 ease-in-out",
              "data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-orange-500 data-[state=active]:text-white data-[state=active]:shadow-lg",
              "data-[state=inactive]:hover:bg-slate-600/70 data-[state=inactive]:text-slate-300"
            )}
          >
            CRUD Test
          </TabsTrigger>
          <TabsTrigger 
            value="simple"
            className={cn(
              "py-2.5 px-2.5 text-xs sm:text-sm rounded-md transition-all duration-200 ease-in-out",
              "data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-emerald-500 data-[state=active]:text-white data-[state=active]:shadow-lg",
              "data-[state=inactive]:hover:bg-slate-600/70 data-[state=inactive]:text-slate-300"
            )}
          >
            Simple Test
          </TabsTrigger>
          <TabsTrigger 
            value="cors_proxy"
            className={cn(
              "py-2.5 px-2.5 text-xs sm:text-sm rounded-md transition-all duration-200 ease-in-out",
              "data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-500 data-[state=active]:to-pink-600 data-[state=active]:text-white data-[state=active]:shadow-lg",
              "data-[state=inactive]:hover:bg-slate-600/70 data-[state=inactive]:text-slate-300"
            )}
          >
            CORS Proxy
          </TabsTrigger>
          <TabsTrigger 
            value="custom_proxy"
            className={cn(
              "py-2.5 px-2.5 text-xs sm:text-sm rounded-md transition-all duration-200 ease-in-out",
              "data-[state=active]:bg-gradient-to-r data-[state=active]:from-lime-500 data-[state=active]:to-yellow-500 data-[state=active]:text-white data-[state=active]:shadow-lg", // New gradient
              "data-[state=inactive]:hover:bg-slate-600/70 data-[state=inactive]:text-slate-300"
            )}
          >
            Custom Proxy
          </TabsTrigger>
        </TabsList>
        <TabsContent value="dashboard" className="mt-6 p-0 md:p-0 rounded-lg shadow-xl overflow-hidden">
          <SchedulingDashboard />
        </TabsContent>
        <TabsContent value="scheduler" className="mt-6 p-0 md:p-0 rounded-lg shadow-xl overflow-hidden">
          <DragDropScheduler />
        </TabsContent>
        <TabsContent value="employees" className="mt-6 p-0 md:p-0 rounded-lg shadow-xl overflow-hidden">
          <EmployeeManager />
        </TabsContent>
        <TabsContent value="connection" className="mt-6 p-0 md:p-0 rounded-lg shadow-xl overflow-hidden">
          <ConnectionTest />
        </TabsContent>
        <TabsContent value="crud" className="mt-6 p-0 md:p-0 rounded-lg shadow-xl overflow-hidden">
          <ScheduleCrudTest />
        </TabsContent>
        <TabsContent value="simple" className="mt-6 p-0 md:p-0 rounded-lg shadow-xl overflow-hidden">
          <SimpleSupabaseTest />
        </TabsContent>
        <TabsContent value="cors_proxy" className="mt-6 p-0 md:p-0 rounded-lg shadow-xl overflow-hidden">
          <CorsProxyTest />
        </TabsContent>
        <TabsContent value="custom_proxy" className="mt-6 p-0 md:p-0 rounded-lg shadow-xl overflow-hidden">
          <CustomProxyTest />
        </TabsContent>
      </Tabs>
      
      <Toaster />
    </div>
  );
};

const App = () => {
  return (
    <AppProviders>
      <AppContent />
    </AppProviders>
  );
};

export default App;