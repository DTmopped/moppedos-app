import React from 'react';

const AppNavigation = ({ views }) => {
  return null;
};

export default AppNavigation;