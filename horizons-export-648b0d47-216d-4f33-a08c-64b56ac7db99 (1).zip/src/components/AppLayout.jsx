import React from 'react';

const AppLayout = ({ children }) => {
  return <>{children}</>;
};

export default AppLayout;